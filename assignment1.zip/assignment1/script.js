// STEP 1 //

/*
var someMonth;
function theMonth 		// function to return current month
currentMonth 		// a constant
var summerMonth; 		// an array of summer months
MyLibrary-aFunction 	// a function
*/

// STEP 2 //

/*
9.0 		// numeric literal expression //
"Goodbye!"	// string literal expression //
False 		// Boolean literal expression //
null 		// null literal expression //
*/

// STEP 3 //

/*
var anExpression = 7 * (2 / 4) + 9;
var theResult - anExpression * 5;
*/

// STEP 4 //

/*
firstName
lastName
$address
$city
$state
zipCode
yourAge
referralSource
maywecontactYou
*/

// STEP 5 //

/*
var firstName, lastName, $state;
firstName = "Tracy"
lastName = "Mosel"
$state = "CA"
*/

// STEP 6 //

/*
var firstName, lastName;
var yourAge = 31;
firstName = "Tracy";
lastName = "Mosel";
console.log(yourAge + 10);
console.log("Your name is" == firstName);
console.log(yourAge == 31);
*/


// STEP 7 //

/*
var firstName = "Tracy";
console.log(firstName + lastName);
var lastName = "Mosel";
*/

// STEP 8 //

/*
var someString = 'Who once said, \"Only two things are infinite, the universe and human stupidity, and I\'m not sure about the former.\"';
console.log(someString);
*/

// STEP 9 //

/*
var email = email;
var newEmail = null;
email = null;
console.log(email);
console.log(newEmail);
var phone;
console.log(phone);
*/

// STEP 10 //

/*
console.log(typeof "tracy");
console.log(typeof 7);
console.log(typeof false);
console.log(typeof null);
console.log(typeof myNumber);
*/

// STEP 11 //

/*
var x = "Hello ";
var z = "Tracy Mosel, ";
var y = "welcome to the JavaScript class!";
alert(x + z + y);

*/

// STEP 12 //

/*
var x = "Hello ";
var z = "Tracy Mosel, ";
var y = "welcome to the JavaScript class!";
var name = "Tracy ";
alert(x + name + y);
*/

// STEP 13 //

/*
var x = "Hello ";
var z = "Tracy Mosel, ";
var name = "Tracy ";
var $course = "JavaScript Class";
var y = "welcome to the "  + $course;
alert(x + name + y);
*/

// STEP 14 //

/*
var x = "Hello ";
var z = "Tracy Mosel, ";
var name = "Tracy \n";
var $course = "JavaScript Class";
var y = "welcome to the "  + $course;
alert(x + name + y);
*/

// STEP 15 //
// STEP 16 //
// STEP 17 //

/*
var x = 10;
var y = 20;
console.log(x +y);
*/

// STEP 18 //

/*
var x = 20;
console.log(x += 20);
*/

// STEP 19 //

/*
var x = 20;
console.log(x *= 5);
*/

// STEP 20 //

/*
var x = 20 % 3;
console.log(x /= 1);
*/

// STEP 21 //

/*
var x = 10;
console.log(x == 10);
*/

// STEP 22 //

/*
var x = 15;

console.log(x > 50);
*/

// STEP 23 //
// STEP 24 //
// STEP 25 //
